public class Main {
    public static void main(String[] args) {
//        Bai 1
        int c = 5;
        for (int i = 1; i <= c; i++) {
            for (int j = 1; j <= c - i; j++) {
                System.out.print(" ");
            }
            for (int k = 1; k <= 2 * i - 1; k++) {
                System.out.print("*");
            }
            System.out.println("");
        }
        for(int i = c-1; i >= 1; i--) {
            for(int j = 1; j <= c - i; j++) {
                System.out.print(" ");
            }
            for(int j=1; j <= 2 * i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
//        Bai 2
        int c = 4;
        int a = 1;
        for (int i = 1; i <= c; i++) {
            for (int j = 1; j <= c - i; j++) {
                System.out.print(" ");
            }
            for (int k = 1; k <= i; k++) {
                System.out.print(a++ +" " );
            }
            System.out.println("");
        }
//        Bai 3
        int a = 4;
        for (int i = 1; i<=a; i++){
            for (int j= 1; j <= i ; j++){
                System.out.print(i);
            }
            System.out.println("");
        }
        Bai 4
        int c = 4;
        int k = 1;
        for (int i = 1; i<= c; i++){
            for (int j = 1; j <=i; j++){
                System.out.print(k++);
            }
            System.out.println("");
        }
//        Bai 5
        int c = 4;
        int a = 1;
        for (int i = 1; i <= c; i++) {
            for (int j = 1; j <= c - i; j++) {
                System.out.print(" ");
            }
            for (int k = 1; k <= i; k++) {
                System.out.print(i +" " );
            }
            System.out.println("");
        }
    }
}